<?php defined('_JEXEC') or die;
echo "site is offline"
