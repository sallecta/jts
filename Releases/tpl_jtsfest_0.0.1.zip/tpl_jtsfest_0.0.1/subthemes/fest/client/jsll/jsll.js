window.addEventListener('load', jsll());

function jsll()
{

const elements = document.getElementsByClassName("jsll_close");
for (let i = 0; i < elements.length; i++) {
console.log(1);
}

}

function jsll_e_close()
{
	console.log(88);
}
